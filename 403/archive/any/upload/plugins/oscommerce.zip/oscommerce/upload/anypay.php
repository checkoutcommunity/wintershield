<?php
require ('includes/application_top.php');

if (isset($_POST["pay_id"]) && isset($_POST["sign"]))
{
	$err = false;
	$message = '';

	// запись логов

	$log_text = 
	"--------------------------------------------------------\n" .
	"operation id		" . $_POST['pay_id'] . "\n" .
	"shop				" . $_POST['merchant_id'] . "\n" .
	"amount				" . $_POST['amount'] . "\n" .
	"currency			" . $_POST['method'] . "\n" .
	"description		" . $_POST['desc'] . "\n" .
	"sign				" . $_POST['sign'] . "\n\n";
	
	$log_file = MODULE_PAYMENT_ANYPAY_LOG;
	
	if (!empty($log_file))
	{
		file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
	}
	
	// проверка цифровой подписи и ip
	
	$valid_ip = true;
	$sIP = str_replace(' ', '', MODULE_PAYMENT_ANYPAY_IPFILTER);
	
	if (!empty($sIP))
	{
		$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
		if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
		'(' . $arrIP[1] . '|\*{1})(\.)' .
		'(' . $arrIP[2] . '|\*{1})(\.)' .
		'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
		{
			$valid_ip = false;
		}
	}
	
	if (!$valid_ip)
	{
		$message .= " - ip-адрес сервера не является доверенным\n" .
		"   доверенные ip: " . $sIP . "\n" .
		"   ip текущего сервера: " . $_SERVER['REMOTE_ADDR'] . "\n";
		$err = true;
	}
		$hash = md5(MODULE_PAYMENT_ANYPAY_MERCHANTID.':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.MODULE_PAYMENT_ANYPAY_SECRETKEY);

	if ($_POST['sign'] != $hash)
	{
		$message .= " - не совпадают цифровые подписи\n";
		$err = true;
	}
	
	if (!$err)
	{
		// загрузка заказа
		
		$order_id = preg_replace('/[^a-zA-Z0-9_-]/', '', substr($_POST['pay_id'], 0, 32));
		
		$curr_query = tep_db_query('select currency from ' . TABLE_ORDERS . ' where orders_id = "' . $order_id . '"');
		$amount_query = tep_db_query('select final_price from ' . TABLE_ORDERS_PRODUCTS . ' where orders_id = "' . $order_id . '"');
		$curr_query_row = tep_db_fetch_array($curr_query);
		$amount_query_row = tep_db_fetch_array($amount_query);
		
		$order_curr = ($curr_query_row['currency'] == 'RUR') ? 'RUB' : $curr_query_row['currency'];
		$order_amount = $amount_query_row['final_price'];

		// проверка суммы и валюты
	
		if ($_POST['amount'] < $order_amount)
		{
			$message .= " - неправильная сумма\n";
			$err = true;
		}

		// проверка статуса
		
		if (!$err)
		{
					$status = MODULE_PAYMENT_ANYPAY_ORDER_STATUS;
					$comment = 'Заказ успешно оплачен через AnyPay';

			
			$sql_data_array = array('orders_status' => $status);
			tep_db_perform('orders', $sql_data_array, 'update', "orders_id='" . $_POST['pay_id'] . "'");
			
			$sql_data_arrax = array(
				'orders_id' => $_POST['pay_id'], 
				'orders_status_id' => $status, 
				'date_added' => 'now()', 
				'customer_notified' => '0', 
				'comments' => $comment
			);
			tep_db_perform('orders_status_history', $sql_data_arrax);
		}
	}
	
	if ($err)
	{
		$to = MODULE_PAYMENT_ANYPAY_EMAILERROR;

		if (!empty($to))
		{
			$message = "Не удалось провести платёж через систему AnyPay по следующим причинам:\n\n" . $message . "\n" . $log_text;
			$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
			"Content-type: text/plain; charset=utf-8 \r\n";
			mail($to, 'Ошибка оплаты', $message, $headers);
		}

		exit($_POST['pay_id'] . '|error');
	}
	else
	{
		exit($_POST['pay_id'] . '|success');
	}
}
?>