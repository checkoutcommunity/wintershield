<?php

class anypay
{
    var $code, $title, $description, $enabled;

    function anypay()
    {
        global $order;

        $this->code = 'anypay';
        $this->title = MODULE_PAYMENT_ANYPAY_TEXT_TITLE;
        $this->description = MODULE_PAYMENT_ANYPAY_TEXT_DESCRIPTION;
        $this->sort_order = MODULE_PAYMENT_ANYPAY_SORT_ORDER;
        $this->enabled = ((MODULE_PAYMENT_ANYPAY_STATUS == 'Да') ? true : false);
    }

    function update_status()
    {
        return false;
    }

    function javascript_validation()
    {
        return false;
    }

    function selection()
    {
        return array('id' => $this->code, 'module' => $this->title);
    }

    function pre_confirmation_check()
    {
        return false;
    }

    function confirmation()
    {
        return false;
    }

    function process_button()
    {
        return false;
    }

    function before_process()
    {
        return false;
    }

    function after_process()
    {
        global $insert_id, $cart, $order;

		$url = MODULE_PAYMENT_ANYPAY_MERCHANTURL;
        $merchant_id = MODULE_PAYMENT_ANYPAY_MERCHANTID;
        $pay_id = $insert_id;
		$currency = $order->info['currency'] == 'RUR' ? 'RUB' : $order->info['currency'];
        $amount = $order->info['total'];
        $desc = 'Order #'.$pay_id;
        $secret_key = MODULE_PAYMENT_ANYPAY_SECRETKEY;
        $sign = md5('RUB:'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id); 
		
		$user_email = @$order->customer["email_address"];
		
        $url = "$url?merchant_id=$merchant_id&pay_id=$pay_id&amount=$amount&desc=".urlencode($desc)."&email=$user_email&sign=$sign";

        $cart->reset(true);
        tep_session_unregister('sendto');
        tep_session_unregister('billto');
        tep_session_unregister('shipping');
        tep_session_unregister('payment');
        tep_session_unregister('comments');
		tep_redirect($url);
    }

    function output_error()
    {
        return false;
    }

    function check()
    {
        if (!isset($this->_check)) 
		{
            $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_ANYPAY_STATUS'");
            $this->_check = tep_db_num_rows($check_query);
        }
		
        return $this->_check;
    }

    function install()
    {
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) 
			values ('Включить модуль', 'MODULE_PAYMENT_ANYPAY_STATUS', 'Да', 'Активировать прием платежей через AnyPay', '6', '3', 'tep_cfg_select_option(array(\'Да\', \'Нет\'), ', now())");
        
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('URL мерчанта', 'MODULE_PAYMENT_ANYPAY_MERCHANTURL', 'https://anypay.io/merchant', 'URL для оплаты в системе AnyPay', '6', '15', now())");
		
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('ID проекта', 'MODULE_PAYMENT_ANYPAY_MERCHANTID', '', 'ID проекта в системе AnyPay', '6', '4', now())");
        
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('Секретный ключ', 'MODULE_PAYMENT_ANYPAY_SECRETKEY', '', 'Секретный ключ проекта', '6', '5', now())");
		
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('Путь до файла для журнала оплат через AnyPay (например, /anypay_orders.log)', 'MODULE_PAYMENT_ANYPAY_LOG', '', 'Если путь не указан, то журнал не записывается', '6', '6', now())");
		
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('IP фильтр', 'MODULE_PAYMENT_ANYPAY_IPFILTER', '', 'Список доверенных ip адресов, можно указать маску', '6', '7', now())");
		
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('Email для ошибок', 'MODULE_PAYMENT_ANYPAY_EMAILERROR', '', 'Email для отправки ошибок оплаты', '6', '8', now())");
        
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) 
			values ('Статус заказа после успешной оплаты', 'MODULE_PAYMENT_ANYPAY_ORDER_STATUS', '0', 'Статус заказа после успешной оплаты', '6', '9', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");
        
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) 
			values ('Статус заказа после неуспешной оплаты', 'MODULE_PAYMENT_ANYPAY_ORDER_STATUS_FAIL', '0', 'Статус заказа после неуспешной оплаты', '6', '10', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");
			
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('Очередность при сортировке', 'MODULE_PAYMENT_ANYPAY_SORT_ORDER', '0', 'Место в списке платежных систем', '6', '11', now())");
        
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('URL успешной оплаты', 'MODULE_PAYMENT_ANYPAY_SUCCESS', '" . HTTP_SERVER . DIR_WS_CATALOG . "checkout_success.php', 'Укажите в настройках проекта AnyPay', '6', '12', now())");
        
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
			values ('URL неуспешной оплаты', 'MODULE_PAYMENT_ANYPAY_FAIL', '" . HTTP_SERVER . DIR_WS_CATALOG . "checkout_payment.php', 'Укажите в настройках проекта AnyPay', '6', '13', now())");
		
		tep_db_query("insert into " . TABLE_CONFIGURATION .
            " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) 
            values ('URL обработчика AnyPay', 'MODULE_PAYMENT_ANYPAY_RESULT', '" . HTTP_SERVER . DIR_WS_CATALOG . "anypay.php', 'Укажите в настройках проекта AnyPay', '6', '14', now())");
	}

    function remove()
    {
        tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys()
    {
        return array(
			'MODULE_PAYMENT_ANYPAY_STATUS', 
			'MODULE_PAYMENT_ANYPAY_MERCHANTURL',
			'MODULE_PAYMENT_ANYPAY_MERCHANTID',
            'MODULE_PAYMENT_ANYPAY_SECRETKEY', 
			'MODULE_PAYMENT_ANYPAY_LOG',
			'MODULE_PAYMENT_ANYPAY_IPFILTER',
			'MODULE_PAYMENT_ANYPAY_EMAILERROR',
            'MODULE_PAYMENT_ANYPAY_ORDER_STATUS', 
			'MODULE_PAYMENT_ANYPAY_ORDER_STATUS_FAIL',
			'MODULE_PAYMENT_ANYPAY_SORT_ORDER',
            'MODULE_PAYMENT_ANYPAY_RESULT', 
			'MODULE_PAYMENT_ANYPAY_SUCCESS',
            'MODULE_PAYMENT_ANYPAY_FAIL'
		);
    }
}
?>