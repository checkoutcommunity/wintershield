<?php
	define('MODULE_PAYMENT_ANYPAY_TEXT_TITLE', 'AnyPay');
	define('MODULE_PAYMENT_ANYPAY_TEXT_DESCRIPTION', 'AnyPay позволяет принимать платежи всеми возможными способами по всему миру!');
?>