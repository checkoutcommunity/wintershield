<?php
	define('MODULE_PAYMENT_ANYPAY_TEXT_TITLE', 'AnyPay');
	define('MODULE_PAYMENT_ANYPAY_TEXT_DESCRIPTION', 'AnyPay allows you to accept payments in all possible ways all over the world!');
?>