<?php
class ControllerExtensionPaymentanypay extends Controller {
	public function index() {
		$data['button_confirm'] = $this->language->get('button_confirm');
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

		$data['merchant'] = $this->config->get('anypay_merchant');
		$data['order_id'] = $this->session->data['order_id'];
		$data['amount'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
		$data['description'] = (empty($order_info['desc'])?'Order #'.$this->session->data['order_id']:base64_encode($order_info['comment']));
		$data['secret_key'] = $this->config->get('anypay_security');
        $data['sign'] = md5('RUB:'.$data['amount'].':'.$data['secret_key'].':'.$data['merchant'].':'.$data['order_id']); 
 
		$this->model_checkout_order->addOrderHistory($data['order_id'], $this->config->get('anypay_order_wait_id'));

		$tpl = 'anypay';
		$data['action'] = 'https://anypay.io/merchant';

		return $this->load->view('extension/payment/'.$tpl, $data);
	}

	public function status() {
		$request = $this->request->post;

		$data['order_id'] = '';
		$data['order_status'] = '';

		if (!empty($request['amount']) && !empty($request['pay_id']) && !empty($request['merchant_id']) && !empty($request['sign'])) {
			$err = false;
			$message = 'Оплачено';
			$this->load->language('extension/payment/anypay');

			// запись логов

			$log_text =
			"--------------------------------------------------------\n" .
			"payment id		" . $request['pay_id'] . "\n" .
			"date time		" . time() . "\n" .
			"merchant		" . $request['merchant_id'] . "\n" .
			"amount			" . $request['amount'] . "\n" .
			"sign			" . $request['sign'] . "\n\n";

			$log_file = $this->config->get('anypay_log_value');

			if (!empty($log_file)) {
				file_put_contents($log_file, $log_text, FILE_APPEND);
			}

			// проверка цифровой подписи и ip

			$hash = md5($this->config->get('anypay_merchant').':'.$request['amount'].':'.$request['pay_id'].':'.$this->config->get('anypay_security'));

			if ($request['sign'] != $hash) {
				$message = "Неверная контрольная подпись";
				$err = true;
			}

			if (!$err) {
				// загрузка заказа
				$this->load->model('checkout/order');
				$order = $this->model_checkout_order->getOrder($request['pay_id']);
				$order_amount = round($order['total']*$order['currency_value'], 2);

				if (!$order) {
					$message = "Неверный ID заказа";
					$err = true;
				} else {

					// проверка суммы и валюты

					if ($request['amount'] < $order_amount) {
						$message = "Неверная сумма";
						$err = true;
					}
				}
			}

			$data['order_id'] = $request['pay_id'];

			if ($err) {
				$data['order_status'] = 'error';
			} else {
				$data['order_status'] = 'success';
				$this->model_checkout_order->addOrderHistory($request['pay_id'], $this->config->get('anypay_order_success_id'));
			}
		}else{
			$message = 'Error_params';
		}

		echo $data['order_id'] . ' | ' . $data['order_status'] . ' | ' . $message;

		return true;
   	}

	public function fail() {
		$this->response->redirect($this->url->link('checkout/checkout'));
		$this->model_checkout_order->addOrderHistory($request['pay_id'], $this->config->get('anypay_order_fail_id'));
		return true;
	}

	public function success() {
		$this->response->redirect($this->url->link('checkout/success'));
		return true;
	}
}