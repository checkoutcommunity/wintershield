<?php
// Text
$_['text_email_subject'] = 'Payment error';
$_['text_email_message1'] = 'Failed to make the payment through the system AnyPay for the following reasons:';
$_['text_email_message2'] = ' - Wrong sign';
$_['text_email_message3'] = ' - The payment status is not success';
$_['text_email_message7'] = ' - Wrong amount';
$_['text_email_message9'] = ' - The order does not exist';