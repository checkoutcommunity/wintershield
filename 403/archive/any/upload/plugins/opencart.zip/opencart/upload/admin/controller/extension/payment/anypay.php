<?php
class ControllerExtensionPaymentanypay extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/anypay');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('anypay', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_payment'] = $this->language->get('text_payment');
		$data['text_success'] = $this->language->get('text_success');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_pay'] = $this->language->get('text_pay');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_anypay'] = $this->language->get('text_anypay');
		$data['text_email_subject'] = $this->language->get('text_email_subject');
		$data['text_email_message1'] = $this->language->get('text_email_message1');
		$data['text_email_message2'] = $this->language->get('text_email_message2');
		$data['text_email_message3'] = $this->language->get('text_email_message3');
		$data['text_email_message4'] = $this->language->get('text_email_message4');
		$data['text_email_message5'] = $this->language->get('text_email_message5');
		$data['text_email_message6'] = $this->language->get('text_email_message6');

		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_merchant'] = $this->language->get('entry_merchant');
		$data['entry_security'] = $this->language->get('entry_security');
		$data['entry_direct_payment'] = $this->language->get('entry_direct_payment');
		$data['entry_order_wait'] = $this->language->get('entry_order_wait');
		$data['entry_order_success'] = $this->language->get('entry_order_success');
		$data['entry_order_fail'] = $this->language->get('entry_order_fail');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$data['entry_log'] = $this->language->get('entry_log');
		$data['entry_merchant'] = $this->language->get('entry_merchant');
		$data['entry_status_url'] = $this->language->get('entry_status_url');
		$data['entry_success_url'] = $this->language->get('entry_success_url');
		$data['entry_fail_url'] = $this->language->get('entry_fail_url');

		$data['help_title'] = $this->language->get('help_title');
		$data['help_merchant'] = $this->language->get('help_merchant');
		$data['help_direct_payment'] = $this->language->get('help_direct_payment');
		$data['help_security'] = $this->language->get('help_security');
		$data['help_log'] = $this->language->get('help_log');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['error_warning'] = (isset($this->error['warning'])?$this->error['warning']:'');
		$data['error_title'] = (isset($this->error['title'])?$this->error['title']:'');
		$data['error_merchant'] = (isset($this->error['merchant'])?$this->error['merchant']:'');
		$data['error_security'] = (isset($this->error['security'])?$this->error['security']:'');

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_payment'),
			'href' => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/anypay', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['action'] = $this->url->link('extension/payment/anypay', 'token=' . $this->session->data['token'], 'SSL');
		$data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');

		$data = $this->checkData($data, 'anypay_title');
		$data = $this->checkData($data, 'anypay_merchant');
		$data = $this->checkData($data, 'anypay_security');

		if (isset($this->request->post['anypay_order_wait_id'])) {
			$data['anypay_order_wait_id'] = $this->request->post['anypay_order_wait_id'];
		} else {
			if (!$this->config->get('anypay_order_wait_id')) {
				$data['anypay_order_wait_id'] = 1;
			} else {
				$data['anypay_order_wait_id'] = $this->config->get('anypay_order_wait_id');
			}
		}

		if (isset($this->request->post['anypay_order_success_id'])) {
			$data['anypay_order_success_id'] = $this->request->post['anypay_order_success_id'];
		} else {
			if (!$this->config->get('anypay_order_success_id')) {
				$data['anypay_order_success_id'] = 5;
			} else {
				$data['anypay_order_success_id'] = $this->config->get('anypay_order_success_id');
			}
		}

		if (isset($this->request->post['anypay_order_fail_id'])) {
			$data['anypay_order_success_id'] = $this->request->post['anypay_order_fail_id'];
		} else {
			if (!$this->config->get('anypay_order_fail_id')) {
				$data['anypay_order_fail_id'] = 10;
			} else {
				$data['anypay_order_fail_id'] = $this->config->get('anypay_order_fail_id');
			}
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$data = $this->checkData($data, 'anypay_status');
		$data = $this->checkData($data, 'anypay_direct_payment');
		$data = $this->checkData($data, 'anypay_status');
		$data = $this->checkData($data, 'anypay_direct_payment');
		$data = $this->checkData($data, 'anypay_log_value');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/anypay.tpl', $data));
	}

	private function checkData($data, $key) {
		if (isset($this->request->post[$key])) {
			$data[$key] = $this->request->post[$key];
		} else {
			$data[$key] = $this->config->get($key);
		}

		return $data;
	}

	protected function validate(){

		if (!$this->user->hasPermission('modify', 'extension/payment/anypay')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['anypay_title']) {
			$this->error['title'] = $this->language->get('error_title');
		}

		if (!$this->request->post['anypay_merchant']) {
			$this->error['merchant'] = $this->language->get('error_merchant');
		}

		if (!$this->request->post['anypay_security']) {
			$this->error['security'] = $this->language->get('error_security');
		}

		return !$this->error;
	}
}