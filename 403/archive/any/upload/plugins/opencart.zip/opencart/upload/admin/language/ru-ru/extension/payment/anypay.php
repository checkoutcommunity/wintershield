<?php
// Heading
$_['heading_title'] = 'AnyPay';

// Text
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_payment'] = 'Оплата';
$_['text_edit'] = 'Изменить AnyPay';
$_['text_success'] = 'Настройки модуля обновлены!';
$_['text_anypay'] = '<a target="_blank" href="https://anypay.io"><img height="27" src="view/image/payment/anypay.png" alt="AnyPay" title="AnyPay" /></a>';

// Entry
$_['entry_title'] = 'Название';
$_['entry_merchant'] = 'ID проекта';
$_['entry_security'] = 'Секретный ключ';
$_['entry_direct_payment'] = 'Прямой платеж';
$_['entry_status'] = 'Статус';
$_['entry_order_wait'] = 'Статус ожидания оплаты';
$_['entry_order_success'] = 'Статус успешной оплаты';
$_['entry_order_fail'] = 'Статус неудачной оплаты';
$_['entry_log'] = 'Путь к журналу транзакций';

// Help
$_['help_title'] = 'Это название, которое пользователь видит во время заказа';
$_['help_merchant'] = 'Идентификатор проекта в системе AnyPay';
$_['help_direct_payment'] = 'Перенаправлять сразу на форму оплаты картой';
$_['help_security'] = 'Секретный ключ оповещения о выполнении платежа. Должен совпадать с секретным ключем, указанным в AnyPay';
$_['help_log'] = 'Путь к файлу, где будет сохраняться вся история оплаты в AnyPay';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';
$_['error_title'] = 'Необходим указать название платежного модуля!';
$_['error_merchant'] = 'Необходимо указать идентификатор проекта!';
$_['error_security'] = 'Необходимо указать секретный ключ!';