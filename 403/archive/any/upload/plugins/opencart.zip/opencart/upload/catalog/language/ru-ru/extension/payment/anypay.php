<?php
// Text
$_['text_email_subject'] = 'Ошибка оплаты';
$_['text_email_message1'] = 'Не удалось произвести оплату через систему AnyPay по следующим причинам:';
$_['text_email_message2'] = ' - Неверная контрольная подпись';
$_['text_email_message3'] = ' - Не удалось провести платеж';
$_['text_email_message7'] = ' - Неверная сумма';
$_['text_email_message9'] = ' - Заказ не существует';