<?php
// Heading
$_['heading_title'] = 'AnyPay';

// Text
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_payment'] = 'Payment';
$_['text_edit'] = 'AnyPay module change';
$_['text_success'] = 'Settings module updated!';
$_['text_anypay'] = '<a target="_blank" href="https://anypay.io"><img height="27" src="view/image/payment/anypay.png" alt="AnyPay" title="AnyPay" /></a>';

// Entry
$_['entry_title'] = 'Title';
$_['entry_merchant'] = 'Project ID';
$_['entry_security'] = 'Secret key';
$_['entry_direct_payment'] = 'Direct payment';
$_['entry_status'] = 'Status';
$_['entry_order_wait'] = 'Status of waiting for payment';
$_['entry_order_success'] = 'Status successful payment';
$_['entry_order_fail'] = 'Status fail payment';
$_['entry_sort_order'] = 'Sorting order';
$_['entry_log'] = 'The path to the transaction log';

// Help
$_['help_title'] = 'This title which the user sees during the order';
$_['help_merchant'] = 'Store identifier registered in the system AnyPAY';
$_['help_direct_payment'] = 'To redirect at once on a form of payment by the card';
$_['help_security'] = 'The secret key specified in a private office of AnyPay';
$_['help_log'] = 'The path to the file , where it will be stored in the entire history of payment AnyPay';

// Error
$_['error_permission'] = 'You are not allowed to control this unit!';
$_['error_title'] = 'It is necessary to specify the title of the payment module!';
$_['error_merchant'] = 'You must specify the project ID!';
$_['error_security'] = 'You must specify the secret key!';