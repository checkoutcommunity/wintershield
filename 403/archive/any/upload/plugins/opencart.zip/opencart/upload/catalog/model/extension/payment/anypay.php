<?php
class ModelExtensionPaymentanypay extends Model
{
  	public function getMethod($address, $total)
	{
		$this->load->language('payment/anypay');

		return array(
       		'code'       => 'anypay',
       		'title'      => 'AnyPay',
			'terms'      => '',
			'sort_order' => $this->config->get('anypay_sort_order')
     	);
  	}
}
?>