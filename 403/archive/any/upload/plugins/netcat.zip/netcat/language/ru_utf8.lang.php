/* AnyPay */
define("NETCAT_MODULE_PAYMENT_ANYPAY_ERROR_MERCHANT_URL_IS_NOT_VALID", "Не указан URL мерчанта");
define("NETCAT_MODULE_PAYMENT_ANYPAY_ERROR_MERCHANT_ID_IS_NOT_VALID", "Не указан ID проекта");
define("NETCAT_MODULE_PAYMENT_ANYPAY_ERROR_SECRET_KEY_IS_NOT_VALID", "Не указан секретный ключ проекта");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_NOT_VALID_IP", " - IP сервера уведомлений не является доверенным");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_VALID_IP", "   доверенные IP: ");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_THIS_IP", "   IP текущего сервера: ");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_HASHES_NOT_EQUAL", " - не совпадают цифровые подписи");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_WRONG_AMOUNT", " - неправильная сумма");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_WRONG_CURRENCY", " - неправильная валюта");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_STATUS_FAIL", " - статус платежа не является success");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_ERR_REASONS", "Не удалось провести платёж через систему AnyPay по следующим причинам:");
define("NETCAT_MODULE_PAYMENT_ANYPAY_MSG_SUBJECT", "Ошибка оплаты");