<?php
	header("Location: /my/orders/");
?>