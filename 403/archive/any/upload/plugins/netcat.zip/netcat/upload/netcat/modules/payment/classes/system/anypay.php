<?php

class nc_payment_system_anypay extends nc_payment_system
{
	protected $automatic = TRUE;
	
	const ERROR_MERCHANT_URL_IS_NOT_VALID = NETCAT_MODULE_PAYMENT_ANYPAY_ERROR_MERCHANT_URL_IS_NOT_VALID;
	const ERROR_MERCHANT_ID_IS_NOT_VALID = NETCAT_MODULE_PAYMENT_ANYPAY_ERROR_MERCHANT_ID_IS_NOT_VALID;
	const ERROR_SECRET_KEY_IS_NOT_VALID = NETCAT_MODULE_PAYMENT_ANYPAY_ERROR_SECRET_KEY_IS_NOT_VALID;
	const MSG_NOT_VALID_IP = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_NOT_VALID_IP;
	const MSG_VALID_IP = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_VALID_IP;
	const MSG_THIS_IP = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_THIS_IP;
	const MSG_HASHES_NOT_EQUAL = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_HASHES_NOT_EQUAL;
	const MSG_WRONG_AMOUNT = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_WRONG_AMOUNT;
	const MSG_WRONG_CURRENCY = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_WRONG_CURRENCY;
	const MSG_WRONG_ORDER_PAYEED = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_WRONG_ORDER_PAYEED;
	const MSG_STATUS_FAIL = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_STATUS_FAIL;
	const MSG_ERR_REASONS = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_ERR_REASONS;
	const MSG_SUBJECT = NETCAT_MODULE_PAYMENT_ANYPAY_MSG_SUBJECT;
	
    protected $accepted_currencies = array('RUB', 'RUR', 'USD', 'EUR');

    protected $settings = array(
        'MERCHANT_URL' => null,
        'MERCHANT_ID' => null,
        'SECRET_KEY' => null,
		'LOG_FILE' => null,
		'IP_FILTER' => null,
		'ADMIN_EMAIL' => null
    );

    protected $request_parameters = array();

    protected $callback_response = array(
        'pay_id' => null,
		'merchant_id' => null,
	    'amount' => null,
		'sign' => null
    );

    public function execute_payment_request(nc_payment_invoice $invoice) 
	{
		$url = $this->get_setting('MERCHANT_URL');
		$merchant_id = $this->get_setting('MERCHANT_ID');
		$pay_id = $invoice->get_id();
		$amount = $invoice->get_amount("%0.2F");
		$currency = $invoice->get_currency() == 'RUR' ? 'RUB' : $invoice->get_currency();
		$desc = 'Order #'.$invoice->get_id();
		$secret_key = $this->get_setting('SECRET_KEY');
		$sign = md5('RUB:'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id); 


        ob_end_clean();
		
        $form = "
            <html>
              <body>
                    <form action='" . $m_url . "' method='post'>" .
                    $this->make_inputs(array(
                        'merchant_id' => $merchant_id,
                        'pay_id' => $pay_id,
                        'amount' => $amount,
	                    'desc' => $desc,
	                    'sign' => $sign
                    )) . "
                </form>
                <script>
                  document.forms[0].submit();
                </script>
              </body>
            </html>";
			
        echo $form;
        exit;
    }

    public function on_response(nc_payment_invoice $invoice = null) 
	{
    }

    public function validate_payment_request_parameters() 
	{
		$m_url = $this->get_setting('MERCHANT_URL');
		$m_id = $this->get_setting('MERCHANT_ID');
		$m_key = $this->get_setting('SECRET_KEY');
		
        if (empty($m_url)) 
		{
            $this->add_error(nc_payment_system_anypay::ERROR_MERCHANT_URL_IS_NOT_VALID);
        }
		
		if (empty($m_id)) 
		{
            $this->add_error(nc_payment_system_anypay::ERROR_MERCHANT_ID_IS_NOT_VALID);
        }
		
		if (empty($m_key))
		{
            $this->add_error(nc_payment_system_anypay::ERROR_SECRET_KEY_IS_NOT_VALID);
        }
    }

    public function validate_payment_callback_response(nc_payment_invoice $invoice = null) 
	{
		$m_operation_id = $this->get_response_value('pay_id');
		$m_sign = $this->get_response_value('sign');
		
		if (isset($m_operation_id) && isset($m_sign))
		{
			$err = false;
			$message = '';

			// запись логов
			
			$log_text = 
				"--------------------------------------------------------\n" .
				"operation id		" . $this->get_response_value('pay_id') . "\n" .
				"shop				" . $this->get_response_value('merchant_id') . "\n" .
				"amount				" . $this->get_response_value('amount') . "\n" .
				"currency			" . $this->get_response_value('method') . "\n" .
				"description			" . $this->get_response_value('desc') . "\n" .
				"sign				" . $this->get_response_value('sign') . "\n\n";
			
			$log_file = $this->get_setting('LOG_FILE');
			
			if (!empty($log_file))
			{
				file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
			}
			
			// проверка цифровой подписи и ip
			
			$valid_ip = true;
			$sIP = str_replace(' ', '', $this->get_setting('IP_FILTER'));
			
			if (!empty($sIP))
			{
				$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
				if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
				'(' . $arrIP[1] . '|\*{1})(\.)' .
				'(' . $arrIP[2] . '|\*{1})(\.)' .
				'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
				{
					$valid_ip = false;
				}
			}
			
			if (!$valid_ip)
			{
				$message .= nc_payment_system_anypay::MSG_NOT_VALID_IP . "\n" . 
				nc_payment_system_anypay::MSG_VALID_IP . $sIP . "\n" . 
				nc_payment_system_anypay::MSG_THIS_IP . $_SERVER['REMOTE_ADDR'] . "\n";
				$err = true;
			}

		$hash = md5($this->get_setting('MERCHANT_ID').':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$this->get_setting('SECRET_KEY'));

			if ($this->get_response_value('sign') != $hash)
			{
				$message .= nc_payment_system_anypay::MSG_HASHES_NOT_EQUAL . "\n";
				$err = true;
			}
			
			if (!$err)
			{
				$order_curr = ($invoice->get_currency() == 'RUR') ? 'RUB' : $invoice->get_currency();
				$order_amount = $invoice->get_amount();
				
				// проверка суммы и валюты
				
				if ($this->get_response_value('amount') < $order_amount)
				{
					$message .= nc_payment_system_anypay::MSG_WRONG_AMOUNT . "\n";
					$err = true;
				}

				// проверка статуса
				
				if (!$err)
				{
						
							if ($invoice->get('status') != 6)
							{
								$invoice->set('status', nc_payment_invoice::STATUS_SUCCESS);
								$invoice->save();
								$this->on_payment_success($invoice);
							}


				}
			}
			
			if ($err)
			{
				$to = $this->get_setting('ADMIN_EMAIL');

				if (!empty($to))
				{
					$message = nc_payment_system_anypay::MSG_ERR_REASONS . "\n\n" . $message . "\n" . $log_text;
					$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
					"Content-type: text/plain; charset=utf-8 \r\n";
					mail($to, nc_payment_system_anypay::MSG_SUBJECT, $message, $headers);
				}
				
				echo ($this->get_response_value('pay_id') . '|error');
			}
			else
			{
				echo ($this->get_response_value('pay_id') . '|success');
			}
		}
    }

    public function load_invoice_on_callback() 
	{
        return $this->load_invoice($this->get_response_value('pay_id'));
    }
}