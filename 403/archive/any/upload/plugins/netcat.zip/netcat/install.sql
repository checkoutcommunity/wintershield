INSERT INTO  `Classificator_PaymentSystem` (`PaymentSystem_ID` ,`PaymentSystem_Name` ,`PaymentSystem_Priority` ,`Value` ,`Checked`)
VALUES (NULL ,  'AnyPay',  '1',  'nc_payment_system_anypay',  '1');