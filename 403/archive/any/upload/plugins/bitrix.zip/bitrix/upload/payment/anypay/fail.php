<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
include(GetLangFileName(dirname(__FILE__) . "/", "/lang.php"));

echo GetMessage("anypay_USER_MESSAGE4")
echo '<p><a href="/personal/order/"> ' . GetMessage("anypay_USER_ORDERS") . '</a></p>';

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php");
?>