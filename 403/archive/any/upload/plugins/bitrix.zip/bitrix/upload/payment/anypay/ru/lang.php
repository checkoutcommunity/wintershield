<?php
global $MESS;
$MESS["anypay_USER_MESSAGE1"] = "Ошибка заказа";
$MESS["anypay_USER_MESSAGE2"] = "Заказ успешно оплачен";
$MESS["anypay_USER_MESSAGE4"] = "Заказ не оплачен";
$MESS["anypay_USER_ORDERS"] = "Перейти к списку заказов";
?>