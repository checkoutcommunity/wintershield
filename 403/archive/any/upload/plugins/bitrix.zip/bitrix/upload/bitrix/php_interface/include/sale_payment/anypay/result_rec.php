<?php 
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

define("NO_KEEP_STATISTIC", true);
define("NOT_CHECK_PERMISSIONS", true);

include(GetLangFileName(dirname(__FILE__) . "/", "/lang.php"));

if (isset($_REQUEST["pay_id"]) && isset($_REQUEST["pass"]))
{
	$err = false;
	$message = '';
	
	// загрузка заказа

	$arOrder = CSaleOrder::GetByID(intval($_REQUEST['pay_id']));
	
	if (!$arOrder)
	{
		$message .= GetMessage("EMAIL_BODY7");
		$err = true;
	}
	else
	{
		CSalePaySystemAction::InitParamArrays($arOrder, $arOrder["ID"]);

		// запись логов

		$log_text = 
		"--------------------------------------------------------\n" .
		"operation id		" . $_REQUEST['pay_id'] . "\n" .
		"shop				" . $_REQUEST['merchant_id'] . "\n" .
		"amount			" . $_REQUEST['amount'] . "\n" .
		"currency			" . $_REQUEST['method'] . "\n" .
		"description		" . $_REQUEST['desc'] . "\n" .
		"sign				" . $_REQUEST['sign'] . "\n\n";
		
		$log_file = CSalePaySystemAction::GetParamValue("anypay_LOG");
		
		if (!empty($log_file))
		{
			file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
		}
		
		
		$valid_ip = true;
		$sIP = str_replace(' ', '', CSalePaySystemAction::GetParamValue("IPFILTER"));
		
		if (!empty($sIP))
		{
			$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
			if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
			'(' . $arrIP[1] . '|\*{1})(\.)' .
			'(' . $arrIP[2] . '|\*{1})(\.)' .
			'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
			{
				$valid_ip = false;
			}
		}
		
		if (!$valid_ip)
		{
			$message .= GetMessage("EMAIL_BODY2") .
			GetMessage("EMAIL_BODY3") . $sIP . "\n" .
			GetMessage("EMAIL_BODY4") . $_SERVER['REMOTE_ADDR'] . "\n";
			$err = true;
		}

		$hash = md5(CSalePaySystemAction::GetParamValue('MERCHANT_ID').':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.CSalePaySystemAction::GetParamValue('SECRET_KEY'));

		if ($_REQUEST['sign'] != $hash)
		{
			$message .= GetMessage("EMAIL_BODY5");
			$err = true;
		}
		
		if (!$err)
		{
			$arFields = array(
				"PS_STATUS" => "Y",
				"PS_STATUS_CODE" => "-",
				"PS_STATUS_DESCRIPTION" => $_REQUEST['pay_id'],
				"PS_STATUS_MESSAGE" => $_REQUEST['pay_id'],
				"PS_SUM" => $_REQUEST["amount"],
				"PS_CURRENCY" => $_REQUEST["method"],
				"PS_RESPONSE_DATE" => date(CDatabase::DateFormatToPHP(CLang::GetDateFormat("FULL", LANG))),
				"USER_ID" => $arOrder["USER_ID"],
			);

			if (CSaleOrder::Update($arOrder["ID"], $arFields))
			{
				$order_curr = $arOrder["CURRENCY"] == 'RUR' ? 'RUB' : $arOrder["CURRENCY"];
				$order_amount = $arOrder["PRICE"]);
				
				// проверка суммы, валюты
			
				if ($_REQUEST['amount'] < $order_amount)
				{
					$message .= GetMessage("EMAIL_BODY8");
					$err = true;
				}
				
				// проверка статуса
				
				if (!$err)
				{

						
							if ($arOrder["PAYED"] == "N")
							{
								CSaleOrder::PayOrder($arOrder["ID"], "Y", false);
								CSaleOrder::StatusOrder($arOrder["ID"], "F");
							}
							
				}
			}
		}
	}
	
	if ($err)
	{
		$to = CSalePaySystemAction::GetParamValue("EMAILERR");

		if (!empty($to))
		{
			$message = GetMessage("EMAIL_BODY1") . $message . "\n" . $log_text;
			$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
			"Content-type: text/plain; charset=utf-8 \r\n";
			mail($to, GetMessage("EMAIL_SUBJECT"), $message, $headers);
		}
		
		exit($_REQUEST["pay_id"] . "|error");
	}
	else
	{
		exit($_REQUEST["pay_id"] . "|success");
	}
}
?>