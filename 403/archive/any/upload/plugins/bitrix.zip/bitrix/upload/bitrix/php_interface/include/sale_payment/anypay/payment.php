<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

include(GetLangFileName(dirname(__FILE__) . "/", "/lang.php"));

$url = CSalePaySystemAction::GetParamValue("MERCHANT_URL");
$merchant_id = CSalePaySystemAction::GetParamValue("MERCHANT_ID");
$pay_id = CSalePaySystemAction::GetParamValue("ORDER_ID");
$amount = CSalePaySystemAction::GetParamValue("SHOULD_PAY");
$desc =  'Order #'.$pay_id;
$secret_key = CSalePaySystemAction::GetParamValue("SECRET_KEY");
$sign = md5('RUB:'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id); 
?>

<form action="<?php echo $url; ?>" method="get">
	<font class="tablebodytext">
		<?php echo GetMessage("anypay_PAYMENT_MESSAGE"); ?><br>
		<?php echo GetMessage("anypay_ORDER_MESSAGE"); ?> <?php echo $pay_id; ?><br>
		<?php echo GetMessage("anypay_TO_PAY"); ?> <b><?php echo $amount; ?></b>
		<p>
			<input type="hidden" name="merchant_id" value="<?php echo $merchant_id; ?>">
			<input type="hidden" name="pay_id" value="<?php echo $pay_id; ?>">
			<input type="hidden" name="amount" value="<?php echo $amount; ?>">
			<input type="hidden" name="desc" value="<?php echo $desc; ?>">
			<input type="hidden" name="sign" value="<?php echo $sign; ?>">
			<input type="submit" name="process" value="<?php echo GetMessage("anypay_SUBMIT");?>">
		</p>
	</font>
</form>