<?php
global $MESS;
$MESS["anypay_USER_MESSAGE1"] = "Error order";
$MESS["anypay_USER_MESSAGE2"] = "Order has been paid successfully";
$MESS["anypay_USER_MESSAGE4"] = "Order is not paid";
$MESS["anypay_USER_ORDERS"] = "Go to list of orders";
?>