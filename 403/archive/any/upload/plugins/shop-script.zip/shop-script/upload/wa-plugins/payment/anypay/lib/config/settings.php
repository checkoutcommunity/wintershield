<?php

return array(
	'm_url' => array(
        'value' => 'https://anypay.io/merchant',
        'title' => 'URL мерчанта',
        'description' => 'URL на оплату в системе AnyPay',
        'control_type' => waHtmlControl::INPUT,
    ),
    'm_shop' => array(
        'value' => '',
        'title' => 'ID проекта',
        'description' => 'ID проекта в системе AnyPay',
        'control_type' => waHtmlControl::INPUT,
    ),
    'm_key' => array(
        'value' => '',
        'title' => 'Секретный ключ',
        'description' => 'Секретный ключ, <br/>который используется для проверки целостности полученной информации<br/>и однозначной идентификации отправителя.',
        'control_type' => waHtmlControl::INPUT,
    ),
	'ip_filter' => array(
        'value' => '',
        'title' => 'IP фильтр',
        'description' => 'Список доверенных ip адресов, можно указать маску',
        'control_type' => waHtmlControl::INPUT,
    ),
	'email_error' => array(
        'value' => '',
        'title' => 'Email для ошибок',
        'description' => 'Email для отправки ошибок оплаты',
        'control_type' => waHtmlControl::INPUT,
    ),
    'log_file' => array(
        'value' => true,
        'title' => 'Путь до файла для журнала оплат через anypay (например, /anypay_orders.log)',
        'description' => 'Если путь не указан, то журнал не записывается',
        'control_type' => waHtmlControl::INPUT,
    )
);
