<?php
return array(
    'name' => ('AnyPay'),
    'description' => 'Оплата с помощью <a href="https://anypay.io" target="_blank">AnyPay</a>.',
    'icon' => 'img/icon.png',
    'logo' => 'img/logo.png',
    'vendor' => 'webasyst',
    'version' => '1.0.0',
    'locale' => array('ru_RU'),
    'type' => waPayment::TYPE_ONLINE,
);
