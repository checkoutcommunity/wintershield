<?php

class anypayPayment extends waPayment implements waIPayment
{
    const VERSION = '1.0';

    protected function initControls(){}

    public function allowedCurrency()
	{
        return array(
            'RUB',
			'RUR',
            'USD',
            'EUR',
        ); 
    }

    public function payment($payment_form_data, $order_data, $auto_submit = false)
	{
        $order = waOrder::factory($order_data);
		$url = $this->m_url;
        $merchant_id = $this->m_shop;
        $pay_id = $order->id;
        $amount = $order->total;
        $currency = $order->currency == 'RUR' ? 'RUB' : $order->currency;
		$desc = 'Order #' . $pay_id;
		$app_id = $this->app_id;
		$merch_id = $this->merchant_id;
		$secret_key = $this->m_key;
		$sign = md5('RUB:'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id); 
		
        $view = wa()->getView();
		$view->assign('url', $url);
		$view->assign('merchant_id', $merchant_id);
        $view->assign('pay_id', $pay_id);
		$view->assign('amount', $amount);
		$view->assign('desc', $desc);
		$view->assign('app_id', $app_id);
        $view->assign('merch_id', $merch_id);
        $view->assign('sign', $sign);
        $view->assign('auto_submit', $auto_submit);
		
		return $view->fetch($this->path . '/templates/payment.html');
    }

    protected function callbackInit($request)
	{		
		$this->app_id = $request['app_id']; 
		$this->merchant_id = $request['merch_id'];
        return parent::callbackInit($request);
    }

    public function callbackHandler($request)
	{	
		$transaction_data = $this->formalizeData($request);
        $action = $request['action'];
        $url = null;

        switch ($action) 
		{
            case 'status':
			
				if (isset($request['pay_id']) && isset($request['sign']))
				{
					$err = false;
					$message = '';
					
					// запись логов
			
					$log_text = 
					"--------------------------------------------------------\n" .
					"operation id       " . $request['pay_id'] . "\n" .
					"shop               " . $request['merchant_id'] . "\n" .
					"amount             " . $request['amount'] . "\n" .
					"currency           " . $request['method'] . "\n" .
					"description        " . $request['desc'] . "\n" .
					"sign               " . $request['sign'] . "\n\n";
					
					$log_file = $this->log_file;
					
					if (!empty($log_file))
					{
						file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
					}
					
					// проверка цифровой подписи и ip
					
					$valid_ip = true;
					$sIP = str_replace(' ', '', $this->ip_filter);
					
					if (!empty($sIP))
					{
						$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
						if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
						'(' . $arrIP[1] . '|\*{1})(\.)' .
						'(' . $arrIP[2] . '|\*{1})(\.)' .
						'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
						{
							$valid_ip = false;
						}
					}
					
					if (!$valid_ip)
					{
						$message .= " - ip-адрес сервера не является доверенным\n" .
						"   доверенные ip: " . $sIP . "\n" .
						"   ip текущего сервера: " . $_SERVER['REMOTE_ADDR'] . "\n";
						$err = true;
					}
		$hash = md5($this->m_shop.':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$this->m_key);

					if ($request['sign'] != $hash)
					{
						$message .= " - не совпадают цифровые подписи\n";
						$err = true;
					}
			
					if (!$err)
					{
						// проверка статуса

							
								$tm = new waTransactionModel();
								$res = $tm->getByFields(array(
									'native_id' => $transaction_data['native_id'],
									'plugin' => $this->id
								));

								if (!$res)
								{
									$transaction_data['plugin'] = $this->id;
									$transaction_data['state'] = self::STATE_CAPTURED;
									$transaction_data = $this->saveTransaction($transaction_data, $request);
									$callback = $this->execAppCallback(self::CALLBACK_PAYMENT, $transaction_data);
									self::addTransactionData($transaction_data['id'], $callback);
								}


					}
					
					if ($err)
					{
						$to = $this->email_error;

						if (!empty($to))
						{
							$message = "Не удалось провести платёж через систему anypay по следующим причинам:\n\n" . $message . "\n" . $log_text;
							$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
							"Content-type: text/plain; charset=utf-8 \r\n";
							mail($to, 'Ошибка оплаты', $message, $headers);
						}
						exit($request['pay_id'] . '|error');
					}
					else
					{
						exit($request['pay_id'] . '|success');
					}
				}
                break;

            case 'success':
				$url = $this->getAdapter()->getBackUrl(waAppPayment::URL_SUCCESS, $transaction_data);
				return array('redirect' => $url);
				break;
				
            case 'fail':
				$url = $this->getAdapter()->getBackUrl(waAppPayment::URL_FAIL, $transaction_data);
				return array('redirect' => $url);
				break;
        }
    }

    protected function formalizeData($transaction_raw_data)
	{
        $transaction_data = parent::formalizeData($transaction_raw_data);
        $transaction_data['native_id'] = $transaction_raw_data['pay_id'];
        $transaction_data['amount'] = $transaction_raw_data['amount'];
        $transaction_data['currency_id'] = $transaction_raw_data['method'];
        $transaction_data['order_id'] = $transaction_raw_data['pay_id'];
		
        switch ($transaction_raw_data['action'])
		{
            case 'success':
                $transaction_data['state'] = self::STATE_CAPTURED;
                $transaction_data['type'] = self::OPERATION_AUTH_CAPTURE;
                $transaction_data['result'] = 1;
                break;
				
            case 'fail':
                $transaction_data['state'] = self::STATE_DECLINED;
                $transaction_data['type'] = self::OPERATION_CANCEL;
                $transaction_data['result'] = 1;
                break;
        }
		
        return $transaction_data;
    }
	
}