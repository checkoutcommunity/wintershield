<?php

class anypay_PaymentSystemDriver extends AMI_PaymentSystemDriver
{
    protected $driverName = 'anypay';

    public function getPayButton(&$aRes, $aData, $bAutoRedirect = false)
    {
        foreach (array('return', 'description') as $k)
		{
            $aData[$fldName] = htmlspecialchars($aData[$k]);
        }

        $aEclusion = array(
			'return',
			'cancel',
			'callback',
			'pay_to_email',
			'amount',
			'currency',
			'description_title',
			'description',
			'order',
			'button_name',
			'button'
        );

        $hiddens = '';
        foreach ($aData as $key => $value) 
		{
            if (!in_array($key, $aEclusion)) 
			{
                $hiddens .=
                    '<input type="hidden" name="' . $key .
                    '" value="' . (is_null($value) ? $aData[$key] : $value) .
                    '" />' . "\n";
            }
        }
        $aData['hiddens'] = $hiddens;

        return parent::getPayButton($aRes, $aData, $bAutoRedirect);
    }

    public function getPayButtonParams($aData, &$aRes)
    {
        $aData += array('anypay_payment' => 0);
		
		if ($aData['currency'] == 'RUR')
		{
			$aData['currency'] = 'RUB';
		}
		
		$aData['desc'] = 'Order #'.$aData['order'];

		$merchant_id 	= $aData['anypay_shop'];
		$pay_id 	= $aData['order'];
		$amount 	= $aData['amount'];
		$secret_key 	= $aData['anypay_secret_key'];

        $aData['sign'] = md5($merchant_id.':'.$amount.':'.$pay_id.':'.$secret_key);    
        $aData['sign'] = md5('RUB:'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id);   
		
        return parent::getPayButtonParams($aData, $aRes);
    }

    public function payProcess($aGet, $aPost, &$aRes, $aCheckData, $aOrderData)
    {
        return parent::payProcess($aGet, $aPost, $aRes, $aCheckData, $aOrderData);
    }

    public function payCallback($aGet, $aPost, &$aRes, $aCheckData, $aOrderData)
    {
        return 1;
    }

    public function getProcessOrder($aGet, $aPost, &$aRes, $aAdditionalParams)
    {
        return parent::getProcessOrder($aGet, $aPost, $aRes, $aAdditionalParams);
    }
}
