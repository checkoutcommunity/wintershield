<?php

chdir(realpath('../../'));
require_once 'ami_env.php';

require_once '_local/eshop/AtoPaymentSystem.php';

class anypay_Callback
{
    public function __construct()
    {
        $this->_secretKey = (string)AtoPaymentSystem::getDriverParameter('anypay', 'anypay_secret_key');
		$this->_ipfilter = (string) AtoPaymentSystem::getDriverParameter('anypay', 'anypay_ip_filter');
		$this->_log = (string)AtoPaymentSystem::getDriverParameter('anypay', 'anypay_log');
		$this->_emailerr = (string)AtoPaymentSystem::getDriverParameter('anypay', 'anypay_email_error');
        $this->_shop = (string)AtoPaymentSystem::getDriverParameter('anypay', 'anypay_shop');
    }

    public function validateRequestParams(array $request)
    {
		if (isset($request['pay_id']) && isset($request['sign']))
		{
			$err = false;
			$message = '';
			
			// запись логов
			
			$log_text = 
				"--------------------------------------------------------\n" .
				"operation id		" . $request["pay_id"] . "\n" .
				"shop				" . $request["merchant_id"] . "\n" .
				"amount				" . $request["amount"] . "\n" .
				"currency			" . $request["method"] . "\n" .
				"description		" . $request["desc"] . "\n" .
				"sign				" . $request["sign"] . "\n\n";
			
			$log_file = $this->_log;
			
			if (!empty($log_file))
			{
				file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
			}
			
			// проверка цифровой подписи и ip
			
			$valid_ip = true;
			$sIP = str_replace(' ', '', $this->_ipfilter);
			
			if (!empty($sIP))
			{
				$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
				if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
				'(' . $arrIP[1] . '|\*{1})(\.)' .
				'(' . $arrIP[2] . '|\*{1})(\.)' .
				'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
				{
					$valid_ip = false;
				}
			}
			
			if (!$valid_ip)
			{
				$message .= " - ip address of the server is not trusted\n" . 
				"   trusted ip: " . $sIP . "\n" . 
				"   ip of the current server: " . $_SERVER['REMOTE_ADDR'] . "\n";
				$err = true;
			}
		$hash = md5($this->_shop.':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$this->_secretKey);

			if ($request["sign"] != $hash)
			{
				$message .= " - Wrong sign\n";
				$err = true;
			}
			
			if (!$err)
			{
				// загрузка заказа
			
				$oDB = AMI::getSingleton('db');

				$order = $oDB->fetchRow(
					DB_Query::getSnippet("SELECT `status`,`sysinfo`,`total` FROM `cms_es_orders` WHERE `id` = %s")
					->q($request['pay_id'])
				);
				
				$sysinfo = unserialize($order['sysinfo']);
				$order_curr = ($sysinfo['fee_curr'] == 'RUR') ? 'RUB' : $sysinfo['fee_curr'];
				$order_amount = $order['total'];
				
				// проверка суммы и валюты
				
				if ($request['amount'] < $order_amount)
				{
					$message .= " - Wrong amount\n";
					$err = true;
				}
				
				// проверка статуса
				
				if (!$err)
				{
					if ($order['status'] != 'checkout')
					{

							
								if ($order['status'] != 'confirmed_done')
								{
									$qupdate = $oDB->fetchValue(DB_Query::getUpdateQuery(
										'cms_es_orders',
										array('status'  => 'confirmed_done'),
										DB_Query::getSnippet('WHERE id IN (%s)')->q($request['pay_id'])
									));
								}
								
								return $request['pay_id'] . '|success';

					}
					else
					{
						return false;
					}
				}
			}
			
			if ($err)
			{
				$to = $this->_emailerr;
				
				if (!empty($to))
				{
					$message = "Failed to make the payment through AnyPay for the following reasons:\n\n" . $message . "\n" . $log_text;
					$headers = "From: no-reply@" . $_SERVER['HTTP_SERVER'] . "\r\n" . 
					"Content-type: text/plain; charset=utf-8 \r\n";
					mail($to, 'Payment error', $message, $headers);
				}
				
				return $request['pay_id'] . '|error';
			}
		}
		else
		{
			return false;
		}
    }
}

$atoanypayCallback = new anypay_Callback();
$resultanypay = $atoanypayCallback->validateRequestParams($_POST);
exit($resultanypay);