<?php
class anypayPayment extends payment 
{
	public function validate()
	{
		return true;
	}

	public static function getOrderId() 
	{
		return (int) getRequest('pay_id');
	}

	public function process($template = null)
	{	
		$this->order->order();
		
		$param = array();
		$param['anypay_url'] 	= $this->object->anypay_url;
		$param['anypay_shop'] 	= $this->object->anypay_shop;
		$param['anypay_orderid'] = $this->order->getId();
		$param['anypay_amount'] = $this->order->getActualPrice();
		$param['anypay_desc']	= 'Order #' . $param['anypay_orderid'];
		$param['anypay_secret_key'] = $this->object->anypay_key;
		$param['anypay_sign'] = md5('RUB:'.$param['anypay_amount'].':'.$param['anypay_secret_key'].':'.$param['anypay_shop'].':'.$param['anypay_orderid']); 
						
		$this->order->setPaymentStatus('initialized');
		
		$FORMS = Array();
		$FORMS = "<form action=" . $param['anypay_url'] . " method='get' name='form_anypay'>
			<input type='hidden' name='merchant_id' value=" . $param['anypay_shop'] . " />
			<input type='hidden' name='pay_id' value=" . $param['anypay_orderid'] . " />
			<input type='hidden' name='amount' value=" . $param['anypay_amount'] . " />
			<input type='hidden' name='desc' value=" . $param['anypay_desc'] . " />
			<input type='hidden' name='sign' value=" . $param['anypay_sign'] . " />
		</form>
		<script type='text/javascript'>document.form_anypay.submit();</script>";

		echo $FORMS; 
		
		list($templateString) = def_module::loadTemplates("emarket/payment/anypay/" . $template, "form_block");
		return def_module::parseTemplate($templateString, $param);
    }

    public function poll() 
	{
		$buffer = outputBuffer::current();
		$buffer->clear();
		$buffer->contentType("text/plain");
		$m_operation_id = getRequest('pay_id');
		$m_sign = getRequest('sign');
		
		if (isset($m_operation_id) && isset($m_sign))
		{
			$err = false;
			$message = '';
			
			// запись логов
			
			$log_text = 
				"--------------------------------------------------------\n" .
				"operation id		" . getRequest('pay_id') . "\n" .
				"shop				" . getRequest('merchant_id') . "\n" .
				"amount				" . getRequest('amount') . "\n" .
				"currency			" . getRequest('method') . "\n" .
				"description		" . getRequest('desc') . "\n" .
				"sign				" . getRequest('sign') . "\n\n";
			
			$log_file = $this->object->anypay_log;
			
			if (!empty($log_file))
			{
				file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
			}
			
			// проверка цифровой подписи и ip
			
			$valid_ip = true;
			$sIP = str_replace(' ', '', $this->object->anypay_ipfilter);
			
			if (!empty($sIP))
			{
				$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
				if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
				'(' . $arrIP[1] . '|\*{1})(\.)' .
				'(' . $arrIP[2] . '|\*{1})(\.)' .
				'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
				{
					$valid_ip = false;
				}
			}
			
			if (!$valid_ip)
			{
				$message .= " - ip-адрес сервера не является доверенным\n" .
				"   доверенные ip: " . $sIP . "\n" .
				"   ip текущего сервера: " . $_SERVER['REMOTE_ADDR'] . "\n";
				$err = true;
			}

			$hash = md5($this->object->anypay_shop.':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$this->object->anypay_key);

			if (getRequest('sign') != $hash)
			{
				$message .= " - Не совпадают цифровые подписи\n";
				$err = true;
			}
			
			if (!$err)
			{
				// загрузка заказа
				
				$currency = strtoupper(mainConfiguration::getInstance()->get('system', 'default-currency'));
				$order_curr = ($currency == 'RUR') ? 'RUB' : $currency;
				$order_amount = $this->order->getActualPrice();
				
				// проверка суммы и валюты
			
				if (getRequest('amount') < $order_amount)
				{
					$message .= " - Неправильная сумма\n";
					$err = true;
				}
				
				// проверка статуса
				
				if (!$err)
				{
							$this->order->setPaymentStatus('accepted');
							$this->order->payment_document_num = getRequest('pay_id');

				}
			}
			
			if ($err)
			{
				$to = $this->object->anypay_emailerr;

				if (!empty($to))
				{
					$message = "Не удалось провести платёж через систему anypay по следующим причинам:\n\n" . $message . "\n" . $log_text;
					$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
					"Content-type: text/plain; charset=utf-8 \r\n";
					mail($to, 'Ошибка оплаты', $message, $headers);
				}
				
				$buffer->push(getRequest('pay_id') . '|error');
			}
			else
			{
				$buffer->push(getRequest('pay_id') . '|success');
			}
		}
		
		$buffer->end();
		return false;
	}
};
?>