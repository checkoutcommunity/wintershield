<?php
	
define ("INCLUDE_CHECK", true);
include "./incl/config.php";
include "./incl/db_connect.php";
include "./incl/onepage.php";

$mysql = new db;
$mysql->connect($config['db']['user'],$config['db']['pass'], $config['db']['name'],$config['db']['host']);
$onepage = new onepage($config,$mysql);

if (isset($_REQUEST['sign']) && isset($_REQUEST['pay_id'])) {
	echo $onepage->up_sign($_REQUEST, false);
} else echo "ok";
?>