<?php
if ( ! defined ( "INCLUDE_CHECK" ) ) die ("hacking attemp!");

$config = array (
	'title' => '', // Название сайта
	
	'servers' => array ( // Если у вас один сервер - ничего не добовляйте, только измените
		array (
			'name' => 'Имя сервера 1', // Имя сервера
			'host' => '91.133.109.111', // Адрес сервера
			'port' => 26366, // Порт сервера
			'groups' => array ( 1, 2 ), 
			'cart' => array ( // Тип таблицы shopping cart 
				'table' => 'shoppingcart',
				'player' => 'player',
				'type' => 'type',
				'item' => 'item',
				'amount' => 'amount',
			),
		),
	),
	
	'record_file' => './record.txt', //Файл рекордов
	
	'db' => array (
		'host' => '', // Хост базы данных
		'user' => '', // Пользователь базы данных
		'name' => '', // Имя базы данных
		'pass' => '', // Пароль базы данных
	),
	'anypay' => array ( // настройки AnyPay 
		'project_id' => '', // ID проекта в системе AnyPay
		'key' => '', // Секретный ключ проекта
	),
	'message' => array (
		'fail' => 'Ошибка',
		'success' => 'Успешно',
	),
	'domain' => 'http://example.com', // Ссылка на ваш сайт. Без слэша в конце
	'groups' => array ( // name - имя, price - цена, perm - имя группы в permissions, time - Срок действия. 0 - вечный
		1 => array (
			'name' => 'Вип',
			'price' => 1,
			'perm' => 'vip',
			'time' => 0,
		),
		2 => array (
			'name' => 'Вип2',
			'price' => 3100,
			'perm' => '3vip',
			'time' => 30,
		),
		3 => array (
			'name' => 'Вип3',
			'price' => 2100,
			'perm' => '1vip',
			'time' => 30,
		),
	),
);