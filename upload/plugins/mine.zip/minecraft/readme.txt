﻿Донат для Minecraft с помощью AnyPay (anypay.io)

Версия: 1.0


Установка:

1. Загрузите содержимое из папки upload в корень сайта.
2. В базе данных выполните запрос из transaction.sql.
3. В файле /incl/config.php заполните данные майнкрафт-сервера, БД и мерчанта AnyPay. 
4. Установка завершена!



URL для AnyPay:

Result URL http://ваш_сайт/payment.php

Метод оповещений POST.