<?php
class Shop_Payment_System_Handler00 extends Shop_Payment_System_Handler
{
	////////////////////////  Настройки AnyPay  ///////////////////////////////////
	
	// url для оплаты в системе AnyPay
	
    protected $url = 'https://anypay.io/merchant';
	
	// ID магазина, зарегистрированного в системе "AnyPay"
	
    protected $merchant_id = '';
	
	// Секретный пароль оповещения о выполнении платежа,<br/>который используется для проверки целостности полученной информации
	
    protected $secret_key = '';
	
	// Комментарий к заказу
	
    protected $anypay_description = '';
	
	// 1 - рубли (RUB), 2 - евро (EUR), 3 - доллары (USD)
	
    protected $anypay_currency = 1;
	
	// доверенные ip-адреса. Указать через запятую, можно указать маску
	
	protected $ipfilter = ''; 
	
	// email для отправки сообщений об ошибках оплаты
	
	protected $emailerror = '';
	
	// путь до файла-журнала (например, /anypay_orders.log). Если пусто, то запись не ведется
	
	protected $anypay_log = ''; 

	////////////////////////  Конец настроек AnyPay  //////////////////////////////
	
	public function execute()
    {
        parent::execute();
        $this->printNotification();
        return $this;
    }
	
    protected function _processOrder()
    {
        parent::_processOrder();
        $this->setXSLs();
        $this->send();
        return $this;
    }

    public function getSumWithCoeff()
    {
        return Shop_Controller::instance()->round(($this->anypay_currency > 0 && $this->_shopOrder->shop_currency_id > 0 
			? 
			Shop_Controller::instance()->getCurrencyCoefficientInShopCurrency(
                $this->_shopOrder->Shop_Currency,
                Core_Entity::factory('Shop_Currency', $this->anypay_currency)
            ) : 0) * $this->_shopOrder->getAmount()
		);
    }

    public function getInvoice()
    {
        return $this->getNotification();
    }

    public function getNotification()
    {
		$url = $this->url;
        $merchant_id = $this->merchant_id;
		$secret_key = $this->secret_key;
        $pay_id = $this->_shopOrder->id;
        $amount = $this->getSumWithCoeff();
        $oShop_Currency = Core_Entity::factory('Shop_Currency')->find($this->anypay_currency);
        $currency_code = $oShop_Currency->code;
        $currency_name = $oShop_Currency->name;
        $desc = 'Order #'.$this->_shopOrder->id;
		
		$currency = ($currency_code == 'RUR') ? 'RUB' : $currency_code;
		$sign = md5($currency.':'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id); 
		
        ob_start();

		?>

		<h1>Оплата через систему AnyPay</h1>
		<p>Сумма к оплате составляет <strong><?php echo $m_amount; ?> <?php echo $currency_name; ?></strong></p>
		<form action="<?php echo $url; ?>" name="pay" method="get">
			<input type="hidden" name="merchant_id" value="<?php echo $merchant_id; ?>">
			<input type="hidden" name="pay_id" value="<?php echo $pay_id; ?>">
			<input type="hidden" name="amount" value="<?php echo $amount; ?>">
			<input type="hidden" name="desc" value="<?php echo $desc; ?>">
			<input type="hidden" name="sign" value="<?php echo $sign; ?>">
			<p><img src="https://anypay.io/template/img/safari_60.png" 
				alt="AnyPay - прием платежей на сайте" 
				title="AnyPay - прием платежей на сайте" 
				style="float:left; margin-right:0.5em; margin-bottom:0.5em; padding-top:0.25em;">
				<b>AnyPay позволяет принимать платежи самыми востребованными способами оплаты</b>. 
			</p>
			<p><input type="submit" value="Оплатить с помощью AnyPay"></p>
		</form>

		<?php

        return ob_get_clean();
    }

    public function paymentProcessing($request)
    {
        $status = $this->ProcessResult($request);
		return $status;
    }

    function ProcessResult($request)
    {

		if (isset($request['pay_id']))
		{
			$err = false;
			$message = '';
			
			// запись логов
			
			$log_text = 
				"--------------------------------------------------------\n" .
				"operation id		" . $request['pay_id'] . "\n" .
				"shop				" . $request['merchant_id'] . "\n" .
				"amount				" . $request['amount'] . "\n" .
				"currency			" . $request['method'] . "\n" .
				"description		" . $request['desc'] . "\n" .
				"sign				" . $request['sign'] . "\n\n";
			
			$log_file = $this->anypay_log;
			
			if (!empty($log_file))
			{
				file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
			}
			
			// проверка цифровой подписи и ip
			
			$valid_ip = true;
			$sIP = str_replace(' ', '', $this->ipfilter);
			
			if (!empty($sIP))
			{
				$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
				if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
				'(' . $arrIP[1] . '|\*{1})(\.)' .
				'(' . $arrIP[2] . '|\*{1})(\.)' .
				'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
				{
					$valid_ip = false;
				}
			}
			
			if (!$valid_ip)
			{
				$message .= " - ip-адрес сервера не является доверенным\n" .
				"   доверенные ip: " . $sIP . "\n" .
				"   ip текущего сервера: " . $_SERVER['REMOTE_ADDR'] . "\n";
				$err = true;
			}

		$hash = md5($this->merchant_id.':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$this->secret_key);

			if ($request["sign"] != $hash)
			{
				$message .= " - не совпадают цифровые подписи\n";
				$err = true;
			}
			
			if (!$err)
			{
				$order_curr = ($this->_shopOrder->Shop_Currency->code == 'RUR') ? 'RUB' : $this->_shopOrder->Shop_Currency->code;
				$order_amount = $this->_shopOrder->getAmount();
				
				// проверка суммы и валюты
			
				if ($request['amount'] < $order_amount)
				{
					$message .= " - неправильная сумма\n";
					$err = true;
				}
				
				// проверка статуса
				
				if (!$err)
				{
							$this->_shopOrder->paid();
							$this->setXSLs();
							$this->send();
				}
			}
			
			if ($err)
			{
				$to = $this->emailerror;

				if (!empty($to))
				{
					$message = "Не удалось провести платёж через систему anypay по следующим причинам:\n\n" . $message . "\n" . $log_text;
					$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
					"Content-type: text/plain; charset=utf-8 \r\n";
					mail($to, "Ошибка оплаты", $message, $headers);
				}
				
				return $request['pay_id'] . '|error';
			}
			else
			{
				return $request['pay_id'] . '|success';
			}
		}
		else
		{
			return false;
		}
    }
}