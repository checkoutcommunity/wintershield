// ------------------------------------------------
// Обработка уведомления об оплате от AnyPay    //
// ------------------------------------------------

$anypay_pay_id = Core_Array::getRequest('pay_id');
$anypay_sign = Core_Array::getRequest('sign');

if (!empty($anypay_pay_id) && !empty($anypay_sign))
{
	$order_id = intval(Core_Array::getRequest('pay_id'));

	$oShop_Order = Core_Entity::factory('Shop_Order')->find($order_id);

	if (!is_null($oShop_Order->id) && !$oShop_Order->paid)
	{
		// Вызов обработчика платежной системы
		
		$anypay_status = Shop_Payment_System_Handler::factory($oShop_Order->Shop_Payment_System)
			->shopOrder($oShop_Order)
			->paymentProcessing($_POST);
			
		exit($anypay_status);
	}
}
// ------------------------------------------------
// /конец обработчика AnyPay                     //
// ------------------------------------------------