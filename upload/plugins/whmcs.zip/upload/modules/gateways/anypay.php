<?php
if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

function anypay_config() {
	$configarray = array(
		'FriendlyName' => array(
			'Type' => 'System',
			'Value' => 'AnyPay'
		),
		'anypay_url' => array(
			'FriendlyName' => 'URL мерчанта (по умолчанию, https://anypay.io/merchant)',
			'Type' => 'text',
			'Size' => '100',
			'Default' => 'https://anypay.io/merchant'
		),
		'anypay_shop' => array(
		  'FriendlyName' => 'ID проекта',
		  'Type' => 'text',
		  'Size' => '50'
		),
		'anypay_secret_key' => array(
		  'FriendlyName' => 'Секретный ключ',
		  'Type' => 'text',
		  'Size' => '100'
		),
		'anypay_logfile' => array(
		  'FriendlyName' => 'Путь до файла для журнализации оплат (например, /anypay_orders.log)',
		  'Type' => 'text',
		  'Size' => '100'
		),
		'anypay_ipfilter' => array(
		  'FriendlyName' => 'IP - фильтр обработчика',
		  'Type' => 'text',
		  'Size' => '100'
		),
		'anypay_email_error' => array(
		  'FriendlyName' => 'Email для ошибок оплаты',
		  'Type' => 'text',
		  'Size' => '100'
		)
	);

	return $configarray;
}

function anypay_link($params) {
	global $_LANG;

	$url = $params['anypay_url'];
	$merchant_id = $params['anypay_shop'];
	$pay_id = $params['invoiceid'];
	$amount = $params['amount'];
	$currency = ($params['currency'] == 'RUR') ? 'RUB' : $params['currency'];
	$desc = 'Order #'.$pay_id;
	$secret_key = $params['anypay_secret_key'];
	$sign = md5($currency.':'.$amount.':'.$secret_key.':'.$merchant_id.':'.$pay_id); 

	$code = '
		<form id = "form_payment_any-pay" method="POST" action="' . $url . '">
			<input type="hidden" name="merchant_id" value="' . $merchant_id . '">
			<input type="hidden" name="pay_id" value="' . $pay_id . '">
			<input type="hidden" name="amount" value="' . $amount . '">
			<input type="hidden" name="desc" value="' . $desc . '">
			<input type="hidden" name="currency" value="' . $currency . '">
			<input type="hidden" name="sign" value="' . $sign . '">
			<input type="submit" value="' . $_LANG['invoicespaynow'] . '" />
		</form>
		';

	return $code;
}