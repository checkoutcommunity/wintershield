<?php

if (isset($_REQUEST['pay_id']))
{
	$order_id = preg_replace('/[^a-zA-Z0-9_-]/', '', substr($_REQUEST['pay_id'], 0, 32));
	header('Location: ' . $_SERVER['HOST'] . '/viewinvoice.php?id=' . $order_id . '&paymentfailed=true');
}