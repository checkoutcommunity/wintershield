<?php
require_once __DIR__ . '/../../../init.php';

$whmcs->load_function('gateway');
$whmcs->load_function('invoice');

$gatewaymodule = 'anypay';
$GATEWAY = getGatewayVariables($gatewaymodule);

if (isset($_POST['pay_id']) && isset($_POST['sign']))
{
	$err = false;
	$message = '';
	
	// запись логов
	
	$log_text = 
		"--------------------------------------------------------\n".
		"operation id       " . $_POST["pay_id"] . "\n".
		"shop               " . $_POST["merchant_id"] . "\n".
		"amount             " . $_POST["amount"] . "\n".
		"currency           " . $_POST["method"] . "\n".
		"description        " . $_POST["desc"] . "\n".
		"sign               " . $_POST["sign"] . "\n\n";

	$log_file = $GATEWAY['anypay_logfile'];
	
	if (!empty($log_file))
	{
		file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
	}
	
	checkCbInvoiceID($_POST['pay_id'], $GATEWAY['name']);
	
	// проверка цифровой подписи и ip
	
	$valid_ip = true;
	$sIP = str_replace(' ', '', $GATEWAY['anypay_ipfilter']);
	
	if (!empty($sIP))
	{
		$arrIP = explode('.', $_SERVER['REMOTE_ADDR']);
		if (!preg_match('/(^|,)(' . $arrIP[0] . '|\*{1})(\.)' .
		'(' . $arrIP[1] . '|\*{1})(\.)' .
		'(' . $arrIP[2] . '|\*{1})(\.)' .
		'(' . $arrIP[3] . '|\*{1})($|,)/', $sIP))
		{
			$valid_ip = false;
		}
	}
	
	if (!$valid_ip)
	{
		$message .= " - IP-адрес сервера не является доверенным\n" . 
		"   доверенные IP: " . $sIP . "\n" .
		"   IP текущего сервера: " . $_SERVER['REMOTE_ADDR'] . "\n";
		$err = true;
	}
	
	$hash = md5($GATEWAY['anypay_shop'].':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$GATEWAY['anypay_secret_key']);

	if ($_POST["sign"] != $hash)
	{
		$message .= " - неверная контрольная подпись\n";
		$err = true;
	}
	
	if (!$err)
	{
				echo $_POST['pay_id'] . '|success';
				checkCbTransID($_POST["pay_id"]);
				addInvoicePayment($_POST['pay_id'], $_POST["pay_id"], $_POST["amount"], '', $gatewaymodule);
				logTransaction($GATEWAY['name'], $_POST, 'Successful');

	}

	if ($err)
	{
		$to = $GATEWAY['anypay_email_error'];

		if (!empty($to))
		{
			$message = "Не удалось провести платёж через систему AnyPay по следующим причинам:\n\n" . $message . "\n" . $log_text;
			$headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n" . 
			"Content-type: text/plain; charset=utf-8 \r\n";
			mail($to, 'Ошибка оплаты', $message, $headers);
		}
		
		echo $_POST['pay_id'] . '|error';
	}
}